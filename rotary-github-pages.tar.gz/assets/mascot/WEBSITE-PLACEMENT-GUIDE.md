# Rotary Mascot Website Placement Guide

| Website section | Recommended asset |
|---|---|
| Homepage hero / welcome | `rotary-mascot-home-welcome.png` |
| Order online | `rotary-mascot-online-ordering.png` |
| Pizza menu | `rotary-mascot-pizza-section.png` |
| Coffee menu | `rotary-mascot-coffee-section.png` |
| Breakfast | `rotary-mascot-breakfast.png` |
| Sandwiches | `rotary-mascot-sandwiches.png` |
| Desserts / Pistachio Affogato | `rotary-mascot-desserts-affogato.png` |
| Dirty Sodas | `rotary-mascot-dirty-sodas.png` |
| Cocktails + Beer | `rotary-mascot-cocktails-beer.png` |
| Pickup / checkout confirmation | `rotary-mascot-pickup.png` |
| Location, map and directions | `rotary-mascot-location.png` |
| Lake Havasu / About | `rotary-mascot-lake-havasu.png` |
| Catering | `rotary-mascot-catering.png` |
| Rewards / Contact | `rotary-mascot-rewards-contact.png` |
| Success, promotion or final CTA | `rotary-mascot-celebration-cta.png` |

## Implementation notes

- All mascot files are transparent PNGs.
- Use each pose only once per page when possible.
- Keep the mascot secondary to menu photography and ordering controls.
- Alternate mascot placement left/right between stacked mobile sections.
- Add descriptive alt text based on the action shown.
- Do not place the red cap over a red background without a light outline, cream shape, or adequate negative space.
