# Rotary brand assets

`rotary-mascot-original.png` is an untouched copy of the client-supplied mascot artwork. `rotary-mascot-banner.webp`, `rotary-mascot-wordmark.png`, and `rotary-mascot-cutout.png` are mechanically optimized derivatives; the character and ROTARY lettering were not redrawn or regenerated.

`rotary-wordmark.png` remains the previously approved compact header treatment so the full supplied banner is not forced into a narrow navigation slot. For production, replace it with an approved transparent vector master if one becomes available.
