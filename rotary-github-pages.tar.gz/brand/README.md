# Rotary brand assets

`rotary-mascot-original.png` is an untouched copy of the original client-supplied mascot artwork. `rotary-mascot-banner.webp`, `rotary-mascot-wordmark.png`, and `rotary-mascot-cutout.png` are mechanically optimized derivatives; the character and ROTARY lettering were not redrawn or regenerated.

`rotary-mascot-full.png` is the later client-supplied transparent full-body mascot. It is used wherever the mascot appears on its own so the hat, coffee cup, shoes, and outline remain complete.

`rotary-text-logo-original.png` is an untouched copy of the client-supplied text logo. `rotary-text-logo.png` removes only the excess white canvas, and `rotary-text-logo-transparent.png` cleanly removes the white background so the approved lettering sits naturally inside the translucent hero panel, navigation, and footer without cropping.
