# Rotary brand assets

`rotary-mascot-original.png` is an untouched copy of the client-supplied mascot artwork. `rotary-mascot-banner.webp`, `rotary-mascot-wordmark.png`, and `rotary-mascot-cutout.png` are mechanically optimized derivatives; the character and ROTARY lettering were not redrawn or regenerated.

`rotary-text-logo-original.png` is an untouched copy of the client-supplied text logo. `rotary-text-logo.png` removes only the excess white canvas so the exact logo fits naturally inside the translucent hero panel, navigation, and footer without cropping.
